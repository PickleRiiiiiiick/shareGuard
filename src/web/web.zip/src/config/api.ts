// Base URL for API requests
export const API_CONFIG = {
    headers: {
        'Content-Type': 'application/json',
    }
};